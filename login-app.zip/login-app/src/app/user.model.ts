export interface IUser {
  id: number;
  firstName: string;
  lastName: string;
  otherName: string;
  gender: string;
  phoneNumber: string;
  email: string;
  password: string;
  confirmPassword: string;
}
